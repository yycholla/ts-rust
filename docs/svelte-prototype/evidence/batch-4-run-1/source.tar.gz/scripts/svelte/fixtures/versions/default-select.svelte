<select defaultValue="b"><option value="a">A</option><option value="b">B</option></select>
