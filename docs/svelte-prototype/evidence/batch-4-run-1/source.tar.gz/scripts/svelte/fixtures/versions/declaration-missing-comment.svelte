{const a= /* comment */ }
