{const a = (() => 1)
()}<p>{a}</p>
