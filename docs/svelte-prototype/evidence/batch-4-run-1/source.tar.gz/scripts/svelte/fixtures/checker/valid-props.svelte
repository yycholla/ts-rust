<script lang="ts">
  import Child from './Child.svelte';
</script>
<Child count={3} />
