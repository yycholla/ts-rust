{const a=1}<div>
