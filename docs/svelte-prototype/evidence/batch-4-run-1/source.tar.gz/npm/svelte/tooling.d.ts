import type { Document, Edit } from './index.js';
import type { Versions, CompilerDiagnostic, CompilerReply } from './compiler.js';
export type ToolingRequest =
  | { op: 'lint'; document: Document; runes?: boolean | null; compatibility?: Versions }
  | { op: 'sessionConfigure'; runes?: boolean | null; compatibility?: Versions }
  | { op: 'sessionOpen'; document: Document }
  | { op: 'sessionChange'; uri: string; version: number; edits: Edit[] }
  | { op: 'sessionClose'; uri: string }
  | { op: 'sessionDiagnostics'; uri: string }
  | { op: 'sessionStats' };
export interface ToolingResult {
  uri?: string;
  version?: number;
  diagnostics?: CompilerDiagnostic[];
  /** Browser tooling provides compiler/lint diagnostics, not project type checking. */
  typeChecking?: false;
  documents?: number;
  sourceBytes?: number;
  cachedDiagnostics?: number;
  invalidated?: string[];
}
export interface Tooling {
  request(request: ToolingRequest): Promise<CompilerReply<ToolingResult>>;
  dispose(): void;
}
export function createTooling(input: BufferSource | WebAssembly.Module): Promise<Tooling>;
