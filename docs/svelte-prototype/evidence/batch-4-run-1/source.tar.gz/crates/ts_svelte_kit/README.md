# SvelteKit integration plugin

This crate owns the framework host contract. It invokes an installed Kit/Vite
pipeline through `npm/svelte-kit`, which replaces component and rune-module
compilation with the Rust compiler protocol. The compiler crate never depends
on this plugin.

Current validated target: MoncuraHR's Kit 2.69.2 / Vite-plugin-svelte 6.2.4.
The loader rejects unvalidated plugin layouts and unknown compilation callsites.
Full builds retain official JavaScript preprocessing, routing, bundling,
Tailwind and Node adapter behavior. They are **hybrid builds**, not fully native
Kit builds. There is no silent fallback to the JavaScript Svelte compiler.

`ts_svelte_kit --help` documents the explicit host paths. Run Kit sync first.
The isolated comparison helper is `scripts/svelte/application-build.py`.
