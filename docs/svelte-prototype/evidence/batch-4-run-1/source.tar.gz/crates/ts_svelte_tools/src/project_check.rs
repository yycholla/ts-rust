//! Native explicit-project checker host. Each semantic check runs in an isolated process.
use serde::Deserialize;
use serde_json::{Value, json};
use std::collections::{BTreeMap, BTreeSet};
use std::io::{Read, Write};
use std::path::{Component, Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};
use ts_svelte::{
    Snapshot,
    compatibility::{self, Versions},
};

static NEXT: AtomicU64 = AtomicU64::new(0);
const INPUT_LIMIT: usize = 16 * 1024 * 1024;
const OUTPUT_LIMIT: usize = 64 * 1024 * 1024;
#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Config {
    pub root: PathBuf,
    pub dependencies: PathBuf,
    pub components: Vec<ComponentInput>,
    #[serde(default)]
    pub files: Vec<String>,
    #[serde(default)]
    pub runes: Option<bool>,
    #[serde(default)]
    pub allow_prerelease: bool,
    #[serde(skip)]
    resolved_versions: Option<Value>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ComponentInput {
    pub path: String,
    pub typescript: bool,
}
fn bounded_read(path: &Path, limit: usize) -> Result<String, String> {
    let file = std::fs::File::open(path).map_err(|e| e.to_string())?;
    if file.metadata().map_err(|e| e.to_string())?.len() > limit as u64 {
        return Err(format!("Input exceeds {limit} bytes"));
    }
    let mut text = String::new();
    file.take(limit as u64 + 1)
        .read_to_string(&mut text)
        .map_err(|e| e.to_string())?;
    if text.len() > limit {
        return Err(format!("Input exceeds {limit} bytes"));
    }
    Ok(text)
}
struct Workspace(PathBuf);
impl Drop for Workspace {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}
impl Config {
    /// Validate the explicit graph and its installed compatibility profile.
    /// # Errors
    /// Rejects invalid, duplicate, reserved or escaping paths and unsupported profiles.
    pub fn validate(&mut self) -> Result<(), String> {
        self.root = self.root.canonicalize().map_err(|e| e.to_string())?;
        self.dependencies = self
            .dependencies
            .canonicalize()
            .map_err(|e| e.to_string())?;
        if self.components.is_empty() || self.components.len() + self.files.len() > 4096 {
            return Err("Explicit project requires 1..4096 inputs including a component".into());
        }
        let mut paths = BTreeSet::new();
        for path in self
            .components
            .iter()
            .map(|c| &c.path)
            .chain(self.files.iter())
        {
            if path.is_empty()
                || Path::new(path)
                    .components()
                    .any(|c| !matches!(c, Component::Normal(_)))
                || path
                    .split(['/', '\\'])
                    .any(|c| matches!(c, "node_modules" | "__svelte" | "tsconfig.json"))
            {
                return Err(
                    "Project input paths must be relative without traversal or reserved names"
                        .into(),
                );
            }
            if !paths.insert(self.input_path(path)?) {
                return Err("Duplicate project input".into());
            }
        }
        self.resolved_versions =
            Some(serde_json::to_value(self.versions()?).map_err(|e| e.to_string())?);
        Ok(())
    }
    fn input_path(&self, path: &str) -> Result<PathBuf, String> {
        let resolved = self
            .root
            .join(path)
            .canonicalize()
            .map_err(|e| format!("{path}: {e}"))?;
        if !resolved.starts_with(&self.root) || !resolved.is_file() {
            return Err("Project input escapes root or is not a file".into());
        }
        Ok(resolved)
    }
    fn versions(&self) -> Result<Versions, String> {
        let package = |name: &str, required: bool| -> Result<Option<String>, String> {
            let path = self.dependencies.join(name).join("package.json");
            if !required && !path.exists() {
                return Ok(None);
            }
            let value: Value = serde_json::from_str(&bounded_read(&path, 1024 * 1024)?)
                .map_err(|e| e.to_string())?;
            Ok(Some(
                value["version"]
                    .as_str()
                    .ok_or("Missing package version")?
                    .into(),
            ))
        };
        let versions = Versions {
            svelte_version: package("svelte", true)?.ok_or("Missing Svelte")?,
            kit_version: package("@sveltejs/kit", false)?,
            typescript_version: package("typescript", false)?,
            allow_prerelease: self.allow_prerelease,
        };
        compatibility::resolve(&versions)?;
        Ok(versions)
    }
    /// Build a session configuration from the project's single resolved profile.
    /// # Errors
    /// Explicit settings conflicting with the project are rejected atomically.
    pub fn session_configuration(&self, settings: &Value) -> Result<Value, String> {
        let versions = serde_json::to_value(self.versions()?).map_err(|e| e.to_string())?;
        if self.resolved_versions.as_ref() != Some(&versions) {
            return Err("Project dependencies changed; reinitialize the server".into());
        }
        if let Some(requested) = settings.get("runes")
            && *requested != json!(self.runes)
        {
            return Err("Session runes conflicts with explicit project runes".into());
        }
        if let Some(requested) = settings.get("compatibility") {
            for (key, value) in requested
                .as_object()
                .ok_or("Expected compatibility object")?
            {
                if versions.get(key) != Some(value) {
                    return Err(format!(
                        "Session {key} conflicts with installed project profile"
                    ));
                }
            }
        }
        Ok(json!({"op":"sessionConfigure","compatibility":versions,"runes":self.runes}))
    }
    /// Reject ambiguous editor ownership before adding a buffer.
    /// # Errors
    /// Project sessions require file URIs and a single URI per canonical source.
    pub fn validate_open_uri(&self, uri: &str, documents: &[Snapshot]) -> Result<(), String> {
        let parsed = url::Url::parse(uri).map_err(|e| e.to_string())?;
        if parsed.query().is_some() || parsed.fragment().is_some() {
            return Err("Project file URI cannot contain query or fragment".into());
        }
        let path = parsed
            .to_file_path()
            .map_err(|()| "Project session requires file URIs")?;
        if let Ok(canonical) = path.canonicalize() {
            for document in documents {
                if document.uri != uri
                    && url::Url::parse(&document.uri)
                        .ok()
                        .and_then(|url| url.to_file_path().ok())
                        .and_then(|path| path.canonicalize().ok())
                        .as_ref()
                        == Some(&canonical)
                {
                    return Err("Source already open under another URI".into());
                }
            }
        }
        Ok(())
    }
    fn source(&self, path: &str, documents: &[Snapshot]) -> Result<Snapshot, String> {
        let resolved = self.input_path(path)?;
        let mut overlay = None;
        for document in documents {
            if let Ok(uri) = url::Url::parse(&document.uri)
                && uri.query().is_none()
                && uri.fragment().is_none()
                && let Ok(file) = uri.to_file_path()
                && file.canonicalize().ok().as_ref() == Some(&resolved)
            {
                if overlay.is_some() {
                    return Err("Multiple open URI aliases for one source file".into());
                }
                overlay = Some(document.clone());
            }
        }
        if let Some(document) = overlay {
            return Ok(document);
        }
        Ok(Snapshot {
            uri: url::Url::from_file_path(self.root.join(path))
                .map_err(|()| "Invalid file URI")?
                .into(),
            version: 0,
            text: bounded_read(&resolved, ts_svelte_compiler::MAX_SOURCE_BYTES)?,
        })
    }
    /// Check disk sources with open-buffer overlays and map diagnostics back.
    /// # Errors
    /// Rejects oversized inputs, incomplete checks, invalid output or a 30-second timeout.
    pub fn check(&self, documents: &[Snapshot]) -> Result<BTreeMap<String, Vec<Value>>, String> {
        self.session_configuration(&json!({}))?;
        let directory = std::env::temp_dir().join(format!(
            "ts-rust-lsp-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        let mut builder = std::fs::DirBuilder::new();
        #[cfg(unix)]
        {
            use std::os::unix::fs::DirBuilderExt;
            builder.mode(0o700);
        }
        builder.create(&directory).map_err(|e| e.to_string())?;
        let cleanup = Workspace(directory);
        let workspace = cleanup.0.join("project");
        let mut bytes = 0;
        let mut source = |path: &str| -> Result<Snapshot, String> {
            let document = self.source(path, documents)?;
            bytes += document.text.len();
            if document.text.len() > ts_svelte_compiler::MAX_SOURCE_BYTES || bytes > INPUT_LIMIT {
                return Err("Project source limit exceeded".into());
            }
            Ok(document)
        };
        let components = self
            .components
            .iter()
            .map(|c| {
                Ok(json!({"path":c.path,"typescript":c.typescript,"document":source(&c.path)?}))
            })
            .collect::<Result<Vec<_>, String>>()?;
        let files = self
            .files
            .iter()
            .map(|path| Ok(json!({"path":path,"text":source(path)?.text})))
            .collect::<Result<Vec<_>, String>>()?;
        let request = serde_json::to_vec(&json!({"workspace":workspace,"dependencies":self.dependencies,"components":components,"files":files,"runes":self.runes,"allowPrerelease":self.allow_prerelease})).map_err(|e| e.to_string())?;
        if request.len() > INPUT_LIMIT {
            return Err("Serialized project request exceeds 16 MiB".into());
        }
        let response = run_checker(&cleanup.0, &request)?;
        if response["ok"] != true {
            return Err(format!(
                "Project check incomplete: {}",
                response
                    .get("error")
                    .or_else(|| response.get("failure"))
                    .unwrap_or(&response)
            ));
        }
        let checker_diagnostics = response["checker"]["diagnostics"]
            .as_array()
            .ok_or("Checker response missing diagnostics")?;
        // The checker preserves TypeScript exit statuses: 0 is clean; 1/2 are
        // completed checks with diagnostics (see ts_svelte_check::check).
        if response["checker"]["ok"] != true
            || !matches!(response["checker"]["status"].as_i64(), Some(0..=2))
        {
            return Err("Checker response missing valid completion status".into());
        }
        let mut diagnostics: BTreeMap<String, Vec<Value>> = BTreeMap::new();
        for d in checker_diagnostics {
            let original = &d["original"];
            let uri = original["uri"].as_str().map(str::to_owned).or_else(|| {
                d["fileName"]
                    .as_str()
                    .and_then(|p| Path::new(p).strip_prefix(&workspace).ok())
                    .and_then(|p| self.source(p.to_str()?, documents).ok().map(|d| d.uri))
            });
            let Some(uri) = uri else {
                return Err(format!("Unattached project diagnostic: {}", d["text"]));
            };
            let range = if original["status"] == "mapped" {
                original["range"].clone()
            } else if original.is_null() {
                json!({"start":d["startPosition"],"end":d["endPosition"]})
            } else {
                Value::Null
            };
            diagnostics.entry(uri.clone()).or_default().push(json!({"uri":uri,"range":range,"code":d["code"],"severity":if d["category"]==1{"error"}else{"warning"},"message":d["text"],"checker":d}));
        }
        Ok(diagnostics)
    }
}

fn run_checker(directory: &Path, request: &[u8]) -> Result<Value, String> {
    let input_path = directory.join("input.json");
    std::fs::File::create(&input_path)
        .and_then(|mut f| f.write_all(request))
        .map_err(|e| e.to_string())?;
    let output_path = directory.join("output.json");
    let output = std::fs::File::create(&output_path).map_err(|e| e.to_string())?;
    let sibling = std::env::current_exe()
        .map_err(|e| e.to_string())?
        .with_file_name(format!("svelte-project{}", std::env::consts::EXE_SUFFIX));
    let mut command = Command::new(sibling);
    command
        .stdin(std::fs::File::open(input_path).map_err(|e| e.to_string())?)
        .stdout(output)
        .stderr(Stdio::null());
    #[cfg(unix)]
    {
        use std::os::unix::process::CommandExt;
        command.process_group(0);
    }
    let mut child = command.spawn().map_err(|e| e.to_string())?;
    let start = Instant::now();
    let outcome = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Ok(status),
            Err(error) => break Err(error.to_string()),
            Ok(None) => {}
        }
        if start.elapsed() > Duration::from_secs(30) {
            break Err("Project check exceeded 30 seconds".into());
        }
        match std::fs::metadata(&output_path) {
            Ok(meta) if meta.len() <= OUTPUT_LIMIT as u64 => {}
            _ => break Err("Checker output exceeds 64 MiB or is unavailable".into()),
        }
        std::thread::sleep(Duration::from_millis(10));
    };
    if outcome.is_err() {
        #[cfg(unix)]
        {
            let _ = Command::new("kill")
                .args(["-KILL", "--", &format!("-{}", child.id())])
                .status();
        }
        let _ = child.kill();
        let _ = child.wait();
    }
    let status = outcome?;
    if !matches!(status.code(), Some(0 | 1)) {
        return Err(format!("Invalid checker exit status: {status}"));
    }
    let response: Value = serde_json::from_str(&bounded_read(&output_path, OUTPUT_LIMIT)?)
        .map_err(|e| format!("Invalid checker response: {e}"))?;
    Ok(response)
}
