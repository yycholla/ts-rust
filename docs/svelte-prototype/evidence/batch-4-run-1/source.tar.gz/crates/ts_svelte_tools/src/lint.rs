//! Native syntax-aware lint subset. It never evaluates project configuration.
use oxc_allocator::Allocator;
use oxc_ast::ast::{BinaryExpression, DebuggerStatement};
use oxc_ast_visit::{Visit, walk};
use oxc_parser::Parser;
use oxc_span::SourceType;
use oxc_syntax::operator::BinaryOperator;
use serde_json::{Value, json};
use ts_svelte::compatibility::Profile;
use ts_svelte::{ByteRange, Document, Snapshot};

struct Rules<'d> {
    document: &'d Document,
    offset: usize,
    diagnostics: Vec<Value>,
}
impl Rules<'_> {
    fn report(&mut self, code: &str, message: &str, start: u32, end: u32) {
        let bytes = ByteRange {
            start: self.offset + start as usize,
            end: self.offset + end as usize,
        };
        self.diagnostics.push(json!({"code":code,"message":message,"severity":"warning","uri":self.document.snapshot().uri,"bytes":bytes,"range":self.document.editor_range(bytes).ok()}));
    }
}
impl<'a> Visit<'a> for Rules<'_> {
    fn visit_debugger_statement(&mut self, node: &DebuggerStatement) {
        self.report(
            "no-debugger",
            "Unexpected debugger statement.",
            node.span.start,
            node.span.end,
        );
    }
    fn visit_binary_expression(&mut self, node: &BinaryExpression<'a>) {
        if matches!(
            node.operator,
            BinaryOperator::Equality | BinaryOperator::Inequality
        ) {
            self.report(
                "eqeqeq",
                "Use strict equality or inequality.",
                node.span.start,
                node.span.end,
            );
        }
        walk::walk_binary_expression(self, node);
    }
}
pub fn lint(snapshot: Snapshot, runes: Option<bool>, profile: &Profile) -> Value {
    if snapshot.text.len() > ts_svelte_compiler::MAX_SOURCE_BYTES {
        return super::failure("size_limit", "Source exceeds 1 MiB");
    }
    let filename = if snapshot.uri.contains("://") {
        let parsed = match url::Url::parse(&snapshot.uri) {
            Ok(uri) if uri.query().is_none() && uri.fragment().is_none() => uri,
            _ => {
                return super::failure(
                    "unsupported_uri",
                    "Expected a URI without query or fragment",
                );
            }
        };
        match percent_encoding::percent_decode_str(parsed.path()).decode_utf8() {
            Ok(path) => path.into_owned(),
            Err(_) => return super::failure("unsupported_uri", "URI path is not UTF-8"),
        }
    } else {
        snapshot.uri.clone()
    };
    let document = Document::new(snapshot);
    let mut diagnostics = Vec::new();
    let mut regions = Vec::new();
    let component = filename.ends_with(".svelte");
    if component {
        let compiled=ts_svelte_compiler::dispatch(json!({"op":"compile","document":document.snapshot(),"target":"server","runes":runes,"compatibility":{"svelteVersion":profile.svelte_version}}).to_string().as_bytes());
        let body = if compiled["ok"] == true {
            &compiled["result"]
        } else {
            &compiled
        };
        diagnostics.extend(body["diagnostics"].as_array().cloned().unwrap_or_default());
        if compiled["ok"] != true {
            return json!({"ok":false,"error":compiled["error"],"diagnostics":diagnostics});
        }
        match rsvelte::Engine::new().prepare(
            document.text(),
            rsvelte::ComponentOptions::new()
                .filename(&document.snapshot().uri)
                .runes(runes),
        ) {
            Ok(prepared) => {
                for script in &prepared.facts().scripts {
                    regions.push((
                        script.content.start() as usize,
                        script.content.end() as usize,
                        script.typescript,
                    ));
                }
            }
            Err(error) => return super::failure("svelte_projection", &error.diagnostic.message),
        }
    } else {
        regions.push((
            0,
            document.text().len(),
            [".ts", ".tsx", ".mts", ".cts"]
                .iter()
                .any(|ext| filename.ends_with(ext)),
        ));
    }
    for (start, end, typescript) in regions {
        let allocator = Allocator::default();
        let source = &document.text()[start..end];
        let source_type = if std::path::Path::new(&filename)
            .extension()
            .is_some_and(|ext| ext == "tsx")
        {
            SourceType::tsx()
        } else if std::path::Path::new(&filename)
            .extension()
            .is_some_and(|ext| ext == "jsx")
        {
            SourceType::jsx()
        } else if typescript {
            SourceType::ts()
        } else {
            SourceType::mjs()
        };
        let parsed = Parser::new(&allocator, source, source_type).parse();
        if parsed.diagnostics.is_empty() {
            let mut visitor = Rules {
                document: &document,
                offset: start,
                diagnostics: Vec::new(),
            };
            visitor.visit_program(&parsed.program);
            diagnostics.extend(visitor.diagnostics);
        } else {
            for error in &parsed.diagnostics {
                diagnostics.push(json!({"code":"js_parse_error","message":error.to_string(),"severity":"error","uri":document.snapshot().uri,"range":null,"bytes":null}));
            }
        }
    }
    json!({"ok":true,"result":{"uri":document.snapshot().uri,"version":document.snapshot().version,"diagnostics":diagnostics,"rules":["svelte/compiler","no-debugger","eqeqeq"],"scope":"compiler diagnostics and script rules; not ESLint/oxlint/Prettier parity"}})
}
