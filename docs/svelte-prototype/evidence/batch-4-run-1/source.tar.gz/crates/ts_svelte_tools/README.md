# Framework-independent Svelte tooling

This crate owns native lint, persistent document sessions and a stdio LSP server.
It depends on the Svelte compiler; it does not import the SvelteKit plugin.

- `svelte-lint PATH [SVELTE_VERSION] [--runes|--legacy]`: recursive native lint with compiler/a11y/CSS
  diagnostics plus AST-based `no-debugger` and `eqeqeq` script rules. Exit 1 means
  diagnostics, 2 means incomplete lint. This is not oxlint/ESLint/Prettier parity.
- `svelte-service`: persistent newline-JSON document sessions and lint.
- `svelte-lsp`: Content-Length JSON-RPC over stdio, UTF-16 incremental edits,
  compiler/lint push and pull diagnostics, configuration invalidation and close
  cleanup. Only implemented capabilities are advertised.
- `ts-rust-svelte/tooling`: the same document-session/lint API through Rust/WASM
  in an isolated disposable worker. It does not run the native project checker.

LSP `initializationOptions` accepts `compatibility`, `runes`, and optionally an
explicit `project` with `root`, `dependencies`, `components: [{path,typescript}]`,
`files: [path]`, and `runes`. Component/file paths are relative to `root`.
The server combines unsaved documents with disk inputs and reruns the native
project checker after changes, saves, closes and watched-file notifications.
This refreshes consumer diagnostics without edits to consumers. Project discovery,
SvelteKit generated types and preprocessing are separate future integration work.
The server persists snapshots and caches compiler diagnostics; semantic checks
use fresh isolated Rust checker processes, not incremental checker-state reuse.
Generated/unmapped diagnostics remain visible at line zero with explicit metadata.

With a project, installed dependency versions and `project.runes` are the single
configuration authority. Conflicting session settings are rejected; dependency
version changes require reinitialization. Encoded file URIs resolve to editor
buffers, with one open URI per canonical source. Inputs must remain within the
project root; reserved paths, duplicates and symlink escapes are rejected.
Checks allow at most 1 MiB per source and 16 MiB per serialized project request,
64 MiB of checker output and 30 seconds per check. Incomplete checks publish an
explicit diagnostic. Project diagnostics publish together after checking, without
an intermediate publication that clears type errors. Pull results omit result IDs
because dependency changes can affect documents whose versions did not change.
